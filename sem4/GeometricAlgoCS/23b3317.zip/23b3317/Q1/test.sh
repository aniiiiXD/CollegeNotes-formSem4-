#!/bin/bash



# Run the program
$PYTHON_CMD python3 Demo.py

